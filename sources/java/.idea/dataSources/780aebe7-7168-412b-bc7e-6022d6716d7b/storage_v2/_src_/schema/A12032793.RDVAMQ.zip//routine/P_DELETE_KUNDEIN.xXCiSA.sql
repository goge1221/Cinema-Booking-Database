create PROCEDURE p_delete_kundein(
    p_person_id  IN  kundein.kundennr%TYPE,
    p_error_code OUT NUMBER
)
AS
BEGIN
    DELETE
    FROM kundein
    WHERE p_person_id = kundein.kundennr;

    p_error_code := SQL%ROWCOUNT;
    IF (p_error_code = 1)
    THEN
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
EXCEPTION
    WHEN OTHERS
        THEN
            p_error_code := SQLCODE;
END p_delete_kundein;
/

