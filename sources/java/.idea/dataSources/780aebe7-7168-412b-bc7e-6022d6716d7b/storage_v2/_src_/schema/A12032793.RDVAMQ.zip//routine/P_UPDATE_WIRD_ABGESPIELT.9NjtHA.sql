create PROCEDURE p_update_wird_abgespielt(
    p_filiale IN WIRD_ABGESPIELT.FILIALE%TYPE,
    p_saal IN WIRD_ABGESPIELT.SAAL%TYPE,
    p_filmname IN WIRD_ABGESPIELT.FILMNAME%TYPE,
    p_datum IN WIRD_ABGESPIELT.DATUM%TYPE,
    p_uhrzeit IN WIRD_ABGESPIELT.BEGINNZEIT%TYPE,
    p_neues_datum IN WIRD_ABGESPIELT.DATUM%TYPE,
    p_error_code OUT NUMBER
)
AS
BEGIN

    UPDATE WIRD_ABGESPIELT
    SET DATUM = p_neues_datum
    WHERE WIRD_ABGESPIELT.FILIALE = p_filiale
      AND
            WIRD_ABGESPIELT.SAAL = p_saal
      AND
            WIRD_ABGESPIELT.FILMNAME = p_filmname
      AND
            WIRD_ABGESPIELT.DATUM = p_datum
      AND
            WIRD_ABGESPIELT.BEGINNZEIT = p_uhrzeit;

     UPDATE KAUFEN_TICKET
         SET DATUM = p_neues_datum
     WHERE KAUFEN_TICKET.FILIALEID = p_filiale
       AND
             KAUFEN_TICKET.SAAL = p_saal
       AND
             KAUFEN_TICKET.FILM = p_filmname
       AND
             KAUFEN_TICKET.DATUM = p_datum
       AND
             KAUFEN_TICKET.ANFANG = p_uhrzeit;

    p_error_code := SQL%ROWCOUNT ;
    IF (p_error_code = 1 or p_error_code = 2)
    THEN
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
EXCEPTION
    WHEN OTHERS
        THEN
            p_error_code := SQLCODE;
END p_update_wird_abgespielt;
/

